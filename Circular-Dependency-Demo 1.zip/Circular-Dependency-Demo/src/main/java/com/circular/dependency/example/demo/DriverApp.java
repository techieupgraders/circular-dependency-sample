package com.circular.dependency.example.demo;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class DriverApp {
	
	private final CarApp carApp;

	  public DriverApp(@Lazy CarApp carApp) {
	      this.carApp = carApp;
	  }
	
	

}
