package com.circular.dependency.example.demo;

import org.springframework.stereotype.Component;

@Component
public class CarApp {
	
	private final DriverApp DriverApp;

	  public CarApp(DriverApp DriverApp) {
	      this.DriverApp = DriverApp;
	  }

}
