package com.circular.dependency.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CircularDependencyB {

	//@Autowired
	private CircularDependencyA circularDependencyA;

	public CircularDependencyA getCircularDependencyA() {
		return circularDependencyA;
	}

	
	public void setCircularDependencyA(CircularDependencyA circularDependencyA) {
		this.circularDependencyA = circularDependencyA;
	}

	public void showDependencyInClassB() {
		System.out.println("My Dependency: " + circularDependencyA);
	}

}
