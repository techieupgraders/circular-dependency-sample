package com.circular.dependency.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class CircularDependencyA {

	@Autowired
	private CircularDependencyB circularDependencyB;

	@PostConstruct          
    public void init() {
		circularDependencyB.setCircularDependencyA(this);
    }

	public void showDependencyInClassA() {
		System.out.println("My Dependency: " + circularDependencyB);
	}

}
